#!/bin/bash
set -ex

# ======================
# ENHANCED CLEANUP SCRIPT
# ======================
CLEANUP_LOG="/tmp/cleanup_$(date +%Y%m%d_%H%M%S).log"
exec > >(sudo tee "$CLEANUP_LOG") 2>&1
echo "=== STARTING COMPLETE CLEANUP $(date) ==="

# 1. SERVICE CLEANUP
echo "=== STOPPING SERVICES ==="
sudo systemctl stop testRabbitMQServer.service 2>/dev/null || true
sudo systemctl stop dmz-sync.service 2>/dev/null || true
sudo systemctl stop dmz-sync.timer 2>/dev/null || true

echo "=== DISABLING SERVICES ==="
sudo systemctl disable testRabbitMQServer.service 2>/dev/null || true
sudo systemctl disable dmz-sync.service 2>/dev/null || true
sudo systemctl disable dmz-sync.timer 2>/dev/null || true

echo "=== REMOVING SYSTEMD FILES ==="
sudo rm -f /etc/systemd/system/testRabbitMQServer.service 2>/dev/null || true
sudo rm -f /etc/systemd/system/dmz-sync.service 2>/dev/null || true
sudo rm -f /etc/systemd/system/dmz-sync.timer 2>/dev/null || true
sudo systemctl daemon-reload
sudo systemctl reset-failed

# 2. RABBITMQ CLEANUP
echo "=== RESETTING RABBITMQ ==="
{
    sudo rabbitmqctl stop_app 2>/dev/null || true
    sudo rabbitmqctl reset 2>/dev/null || true
    sudo rabbitmqctl start_app 2>/dev/null || true
    sudo rabbitmqctl delete_user test 2>/dev/null || true
    sudo rabbitmqctl delete_vhost testHost 2>/dev/null || true
    sudo rm -f /usr/local/bin/rabbitmqadmin 2>/dev/null || true
} || echo "RabbitMQ cleanup completed with warnings"

# 3. MYSQL NUCLEAR OPTION
echo "=== COMPLETELY REMOVING MYSQL ==="
{
    # Stop MySQL first
    sudo systemctl stop mysql 2>/dev/null || true
    
    # Full purge
    sudo apt-get purge -y mysql-server mysql-client mysql-common mysql-server-core-* mysql-client-core-*
    
    # Remove all database files
    sudo rm -rf /etc/mysql /var/lib/mysql /var/log/mysql*
    
    # Clean up dependencies
    sudo apt-get autoremove -y
    sudo apt-get autoclean
} || echo "MySQL removal completed with warnings"

# 4. PACKAGE CLEANUP
echo "=== REMOVING INSTALLED PACKAGES ==="
sudo apt-get remove -y --purge \
    php php-amqp php-mysql \
    rabbitmq-server \
    wget 2>/dev/null || true
sudo apt-get autoremove -y

# 5. PROJECT FILES CLEANUP (PRESERVING DIRECTORY)
echo "=== CLEARING PROJECT FILES ==="
PROJECT_DIR="$HOME/git/rabbitmqphp_example"
if [ -d "$PROJECT_DIR" ]; then
    echo "Removing contents of $PROJECT_DIR..."
    # First try with find (more precise)
    sudo find "$PROJECT_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null || {
        echo "Using alternative cleanup method..."
        # Fallback method if find fails
        sudo rm -rf "$PROJECT_DIR"/* "$PROJECT_DIR"/.* 2>/dev/null || true
    }
    echo "Directory structure preserved at $PROJECT_DIR"
    # Verify cleanup
    if [ "$(ls -A "$PROJECT_DIR")" ]; then
        echo "Warning: Some files remain in $PROJECT_DIR"
    else
        echo "Project directory is now empty"
    fi
else
    echo "Project directory not found at $PROJECT_DIR - skipping"
fi

# 6. TEMP FILE CLEANUP
echo "=== CLEANING TEMPORARY FILES ==="
sudo rm -rf /tmp/rabbitmq* /tmp/mysql* 2>/dev/null || true

# FINAL CONFIRMATION
echo "=== VERIFYING CLEANUP ==="
{
    echo "Services status:"
    systemctl list-unit-files | grep -E 'testRabbitMQ|dmz-sync' || echo "No services found"
    
    echo "MySQL check:"
    which mysql || echo "MySQL not found"
    
    echo "RabbitMQ check:"
    which rabbitmqctl || echo "RabbitMQ not found"
    
    echo "Project directory status:"
    ls -ld "$PROJECT_DIR" 2>/dev/null || echo "Project directory not found"
    if [ -d "$PROJECT_DIR" ]; then
        echo "Contents count: $(find "$PROJECT_DIR" -mindepth 1 | wc -l)"
    fi
}

echo "=== CLEANUP COMPLETED SUCCESSFULLY ==="
echo "Full cleanup log available at: $CLEANUP_LOG"
