#!/usr/bin/php
<?php
require_once('path.inc');
require_once('get_host_info.inc');
require_once('rabbitMQLib.inc');
require_once('mysqlconnect.php');  // Include mysqlconnect.php for database operations

// Function to process the request (login, logout, etc.)
function requestProcessor($request)
{
    echo "Received request" . PHP_EOL;
    var_dump($request);

    if (!isset($request['type'])) {
        return ["status" => "error", "message" => "Unsupported message type"];
    }

    switch ($request['type']) {
        case "login":
            return doLogin($request['username'], $request['password']);
        case "logout":
            return doLogout($request['sessionToken']);
        case "register":
            return doRegister($request['username'], $request['password']);
        case "fetch_all_reviews":
            return fetchAllReviews();
        
        case "submit_rating_review":
            return submitRatingReview($request['username'], $request['placeName'], $request['rating'], $request['review']);
        case "fetch_ratings_reviews":
            return fetchRatingsReviews($request['placeName']);
        
        case "filter_reviews_by_restaurant":
            return fetchReviewsByRestaurant($request['placeName']);
        
        case "filter":
           // Ensure required fields are present
           if (!isset($request['city']) || !isset($request['keyword']) || !isset($request['rating'])) {
               return ["status" => "error", "message" => "Missing filter information"];
           }
           // Pass all filters to doFilter (even if some are empty)
           return doFilter(
               $request['city'] ?? '',
               $request['keyword'] ?? '',
               $request['rating'] ?? '',
               $request['dietary'] ?? '',
               $request['cuisine'] ?? ''
           );
        
        case "book_reservation":
            if (!isset($request['restaurant']) || !isset($request['date']) || !isset($request['time'])) {
                return ["status" => "error", "message" => "Missing reservation fields"];
            }
            return bookReservation(
                $request['restaurant'],
                $request['date'],
                $request['time'],
                $request['username'] ?? null
            );
        case "get_reservations":
            return getReservations($request['username'] ?? null);
        case "cancel_reservation":
            return cancelReservation(
                $request['reservation_id'],
                $request['username'] ?? null
            );

        default:
            return ["status" => "error", "message" => "Invalid request type"];
    }
}

// Start the RabbitMQ server to process requests
$server = new rabbitMQServer("localRabbitMQ.ini", "testServer");
// $server = new rabbitMQServer("testRabbitMQ.ini", "testServer");
$server->process_requests('requestProcessor');
exit();
?>