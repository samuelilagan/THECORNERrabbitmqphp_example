#!/bin/bash
set -ex

# Improved logging setup
LOG_FILE="/tmp/setup_$(date +%Y%m%d_%H%M%S).log"
exec > >(sudo tee "$LOG_FILE") 2>&1
echo "=== Starting Dependency Installation $(date) ==="

# Get current user and home directory
CURRENT_USER=$(whoami)
CURRENT_HOME=$(eval echo ~$CURRENT_USER)
PROJECT_DIR="$CURRENT_HOME/git/rabbitmqphp_example"

# Install packages
echo "=== Installing Dependencies ==="
sudo apt-get update && sudo apt-get install -y \
   php php-amqp php-mysql \
   rabbitmq-server mysql-server \
   wget || { echo "Package install failed"; exit 1; }

# Configure RabbitMQ
echo "=== Configuring RabbitMQ ==="
sudo rabbitmq-plugins enable rabbitmq_management
sudo systemctl restart rabbitmq-server || { echo "RabbitMQ restart failed"; exit 1; }
sleep 10

# Reset RabbitMQ test environment
echo "=== Configuring RabbitMQ Test Environment ==="
{
   sudo rabbitmqctl delete_user test 2>/dev/null || true
   sudo rabbitmqctl delete_vhost testHost 2>/dev/null || true
   sudo rabbitmqctl add_vhost testHost || { echo "Failed to create vhost"; exit 1; }
   sudo rabbitmqctl add_user test test || { echo "Failed to create user"; exit 1; }
   sudo rabbitmqctl set_user_tags test administrator || { echo "Failed to set admin tag"; exit 1; }
   sudo rabbitmqctl set_permissions -p testHost test ".*" ".*" ".*" || { echo "Failed to set permissions"; exit 1; }
}

# Install rabbitmqadmin
echo "=== Installing rabbitmqadmin ==="
sudo wget -q -O /usr/local/bin/rabbitmqadmin \
   http://127.0.0.1:15672/cli/rabbitmqadmin || {
   sleep 5
   sudo wget -q -O /usr/local/bin/rabbitmqadmin \
       http://127.0.0.1:15672/cli/rabbitmqadmin || {
       echo "Failed to download rabbitmqadmin"
       exit 1
   }
}
sudo chmod +x /usr/local/bin/rabbitmqadmin

# Create RabbitMQ objects
echo "=== Creating RabbitMQ Objects ==="
{
    # Exchanges
    rabbitmqadmin declare exchange \
       --vhost=testHost \
       name=testExchange \
       type=direct \
       durable=true \
       --username=test \
       --password=test || { echo "Failed to create testExchange"; exit 1; }

    rabbitmqadmin declare exchange \
       --vhost=testHost \
       name=apiExchange \
       type=direct \
       durable=true \
       --username=test \
       --password=test || { echo "Failed to create apiExchange"; exit 1; }

    # Queues
    rabbitmqadmin declare queue \
       --vhost=testHost \
       name=testQueue \
       durable=false \
       auto_delete=true \
       --username=test \
       --password=test || { echo "Failed to create testQueue"; exit 1; }

    rabbitmqadmin declare queue \
       --vhost=testHost \
       name=apiQueue \
       durable=true \
       auto_delete=false \
       --username=test \
       --password=test || { echo "Failed to create apiQueue"; exit 1; }

    # Bindings
    rabbitmqadmin declare binding \
       --vhost=testHost \
       source=testExchange \
       destination=testQueue \
       routing_key=test_routing_key \
       --username=test \
       --password=test || { echo "Failed to create test binding"; exit 1; }

    rabbitmqadmin declare binding \
       --vhost=testHost \
       source=apiExchange \
       destination=apiQueue \
       routing_key=api_routing_key \
       --username=test \
       --password=test || { echo "Failed to create api binding"; exit 1; }
}

# Verify RabbitMQ setup
echo "=== Verifying RabbitMQ Setup ==="
rabbitmqadmin list exchanges --vhost=testHost --username=test --password=test
rabbitmqadmin list queues --vhost=testHost --username=test --password=test
rabbitmqadmin list bindings --vhost=testHost --username=test --password=test

# Configure MySQL
echo "=== Configuring MySQL Database ==="
sudo mysql << 'MYSQL_SCRIPT'
CREATE DATABASE IF NOT EXISTS users;
CREATE USER IF NOT EXISTS 'testUser'@'localhost' IDENTIFIED BY '12345';
GRANT ALL PRIVILEGES ON users.* TO 'testUser'@'localhost';
FLUSH PRIVILEGES;
MYSQL_SCRIPT

# ================================================
# INTENTIONAL SERVICE STOPPAGE - MySQL WILL BE DOWN
# ================================================
echo "=== Stopping MySQL Service (Intentional) ==="
sudo systemctl stop mysql || { echo "Warning: Could not stop MySQL"; }
# Verification
if systemctl is-active --quiet mysql; then
   echo "Error: MySQL is still running!"
   exit 1
else
   echo "MySQL successfully stopped"
fi

# Restore database from backup (will fail while MySQL is down)
echo "=== Attempting Database Restoration (Should Fail) ==="
sudo mysql -u root users < "$PWD/full_mysql_backup.sql" && {
   echo "Error: MySQL restoration succeeded when it should have failed"
   exit 1
} || echo "MySQL restoration failed as expected (service is stopped)"

# Verify MySQL setup (will fail)
echo "=== Verifying Database (Should Fail) ==="
sudo mysql -u testUser -p12345 -e "USE users; SHOW TABLES;" && {
   echo "Error: MySQL verification succeeded when it should have failed"
   exit 1
} || echo "MySQL verification failed as expected"

# Configure systemd services
echo "=== Configuring Systemd Services ==="

# Function to configure a service
configure_service() {
    local SERVICE_FILE="$1"
    local EXEC_START="$2"
    
    if [ ! -f "$SERVICE_FILE" ]; then
       echo "Error: Service file not found at $SERVICE_FILE"
       return 1
    fi

    # Modify the service file to use current user
    sudo sed -i "s|User=.*|User=$CURRENT_USER|g" "$SERVICE_FILE"
    sudo sed -i "s|Group=.*|Group=$CURRENT_USER|g" "$SERVICE_FILE"
    sudo sed -i "s|WorkingDirectory=.*|WorkingDirectory=$PROJECT_DIR|g" "$SERVICE_FILE"
    sudo sed -i "s|ExecStart=.*|ExecStart=$EXEC_START|g" "$SERVICE_FILE"

    # Install service
    sudo cp "$SERVICE_FILE" /etc/systemd/system/ || { echo "Failed to copy service file"; return 1; }
    sudo chmod 644 /etc/systemd/system/$(basename "$SERVICE_FILE") || { echo "Failed to set permissions"; return 1; }
}

# Configure services
configure_service "$PWD/testRabbitMQServer.service" "/usr/bin/php $PROJECT_DIR/testRabbitMQServer.php"
configure_service "$PWD/dmz-sync.service" "/usr/bin/php $PROJECT_DIR/dmzRabbitMQClient.php"

# Configure timer if exists
if [ -f "$PWD/dmz-sync.timer" ]; then
    sudo cp "$PWD/dmz-sync.timer" /etc/systemd/system/ || { echo "Failed to copy timer file"; exit 1; }
    sudo chmod 644 /etc/systemd/system/dmz-sync.timer || { echo "Failed to set timer permissions"; exit 1; }
fi

# Reload systemd
sudo systemctl daemon-reload || { echo "Failed to reload systemd"; exit 1; }

# Enable and start services
echo "=== Enabling Services ==="
sudo systemctl enable testRabbitMQServer.service || { echo "Failed to enable testRabbitMQServer"; exit 1; }
sudo systemctl enable dmz-sync.service || { echo "Failed to enable dmz-sync.service"; exit 1; }

if [ -f "/etc/systemd/system/dmz-sync.timer" ]; then
    sudo systemctl enable dmz-sync.timer || { echo "Failed to enable dmz-sync.timer"; exit 1; }
    sudo systemctl start dmz-sync.timer || { echo "Failed to start dmz-sync.timer"; exit 1; }
fi

# Start services with verification
start_and_verify_service() {
    local SERVICE_NAME="$1"
    
    echo "=== Starting $SERVICE_NAME ==="
    sudo systemctl start "$SERVICE_NAME" || {
       echo "Service start failed - checking logs"
       journalctl -u "$SERVICE_NAME" -n 50 --no-pager
       exit 1
    }

    sleep 2
    if ! systemctl is-active --quiet "$SERVICE_NAME"; then
       echo "$SERVICE_NAME is not running - checking status"
       sudo systemctl status "$SERVICE_NAME" --no-pager
       journalctl -u "$SERVICE_NAME" -n 50 --no-pager
       exit 1
    fi
}

start_and_verify_service "testRabbitMQServer.service"
start_and_verify_service "dmz-sync.service"

# Final verification
echo "=== Final Verification ==="
echo "RabbitMQ Objects:"
rabbitmqadmin list exchanges --vhost=testHost --username=test --password=test
rabbitmqadmin list queues --vhost=testHost --username=test --password=test
rabbitmqadmin list bindings --vhost=testHost --username=test --password=test

echo "=== MySQL Status ==="
sudo systemctl status mysql --no-pager || echo "MySQL is down as intended"

echo "=== Service Statuses ==="
sudo systemctl status testRabbitMQServer.service --no-pager || true
sudo systemctl status dmz-sync.service --no-pager || true

if [ -f "/etc/systemd/system/dmz-sync.timer" ]; then
    sudo systemctl status dmz-sync.timer --no-pager || true
fi

echo "=== Setup Complete ==="
echo "MySQL service was intentionally stopped"
echo "To restart MySQL later, run: sudo systemctl start mysql"
echo "Log file available at: $LOG_FILE"
