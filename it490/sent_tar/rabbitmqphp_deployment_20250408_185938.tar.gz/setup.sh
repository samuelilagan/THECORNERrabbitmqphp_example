#!/bin/bash
set -ex
exec > >(tee /home/$(whoami)/setup.log) 2>&1


DEPLOY_DIR="/opt/rabbitmqphp_deployment/current"
echo "=== Initializing Deployment in $DEPLOY_DIR ==="


# Clean previous deployment
sudo rm -rf "$DEPLOY_DIR"
sudo mkdir -p "$DEPLOY_DIR"


# Extract files (assuming deployment.tar.gz is in current dir)
sudo tar -xzvf ./deployment.tar.gz -C "$DEPLOY_DIR" || {
   echo "Extraction failed"
   exit 1
}


cd "$DEPLOY_DIR/app"


echo "=== Installing Dependencies ==="
sudo apt-get update && sudo apt-get install -y \
   php php-amqp php-mysql \
   rabbitmq-server mysql-server \
   wget || { echo "Package install failed"; exit 1; }


# Download rabbitmqadmin after RabbitMQ is installed
echo "=== Installing rabbitmqadmin ==="
sleep 10
sudo wget -q -O /usr/local/bin/rabbitmqadmin \
   http://127.0.0.1:15672/cli/rabbitmqadmin || {
   sleep 5
   sudo wget -q -O /usr/local/bin/rabbitmqadmin \
       http://127.0.0.1:15672/cli/rabbitmqadmin || {
       echo "Failed to download rabbitmqadmin"
       exit 1
   }
}
sudo chmod +x /usr/local/bin/rabbitmqadmin


echo "=== Configuring MySQL Database ==="
sudo mysql << 'MYSQL_SCRIPT'
DROP DATABASE IF EXISTS users;
CREATE DATABASE users;
CREATE USER IF NOT EXISTS 'testUser'@'localhost' IDENTIFIED BY '12345';
GRANT ALL PRIVILEGES ON users.* TO 'testUser'@'localhost';
FLUSH PRIVILEGES;
MYSQL_SCRIPT


# Verify MySQL setup
sudo mysql -u testUser -p12345 -e "SHOW DATABASES;" || {
   echo "MySQL configuration failed";
   exit 1;
}


echo "=== Configuring RabbitMQ ==="
sudo rabbitmq-plugins enable rabbitmq_management
sudo systemctl restart rabbitmq-server || { echo "RabbitMQ restart failed"; exit 1; }


sleep 10


echo "=== Forcefully Resetting RabbitMQ Test User ==="
{
   sudo rabbitmqctl delete_user test 2>/dev/null
   sudo rabbitmqctl delete_vhost testHost 2>/dev/null
} || true


echo "=== Creating Fresh RabbitMQ Configuration ==="
sudo rabbitmqctl add_vhost testHost || { echo "Failed to create vhost"; exit 1; }
sudo rabbitmqctl add_user test test || { echo "Failed to create user"; exit 1; }
sudo rabbitmqctl set_user_tags test administrator || { echo "Failed to set admin tag"; exit 1; }
sudo rabbitmqctl set_permissions -p testHost test ".*" ".*" ".*" || { echo "Failed to set permissions"; exit 1; }


echo "=== Creating RabbitMQ Objects ==="
rabbitmqadmin declare exchange \
   --vhost=testHost \
   name=testExchange \
   type=direct \
   durable=true \
   --username=test \
   --password=test || { echo "Failed to create exchange"; exit 1; }


rabbitmqadmin declare queue \
   --vhost=testHost \
   name=testQueue \
   durable=true \
   --username=test \
   --password=test || { echo "Failed to create queue"; exit 1; }


rabbitmqadmin declare binding \
   --vhost=testHost \
   source=testExchange \
   destination=testQueue \
   routing_key=testKey \
   --username=test \
   --password=test || { echo "Failed to create binding"; exit 1; }


# ======================
# SYSTEMD SERVICE SETUP
# ======================
echo "=== Configuring Systemd Service ==="
SERVICE_FILE="$DEPLOY_DIR/app/testRabbitMQServer.service"


if [ ! -f "$SERVICE_FILE" ]; then
   echo "Error: Service file not found at $SERVICE_FILE"
   exit 1
fi


{
   sudo cp "$SERVICE_FILE" /etc/systemd/system/ && \
   sudo chmod 644 /etc/systemd/system/testRabbitMQServer.service && \
   sudo systemctl daemon-reload && \
   sudo systemctl enable testRabbitMQServer.service && \
   sudo systemctl start testRabbitMQServer.service
} || {
   echo "Failed to configure systemd service"
   exit 1
}


echo "=== Verification ==="
echo "RabbitMQ Objects:"
rabbitmqadmin list exchanges --vhost=testHost --username=test --password=test
rabbitmqadmin list queues --vhost=testHost --username=test --password=test
rabbitmqadmin list bindings --vhost=testHost --username=test --password=test


echo "=== Service Status ==="
sudo systemctl status testRabbitMQServer.service --no-pager || {
   echo "⚠ Service check failed"
   exit 1
}


echo "Deployment Complete"
