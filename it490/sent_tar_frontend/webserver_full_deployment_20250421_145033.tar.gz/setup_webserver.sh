#!/bin/bash
set -ex

# Logging setup
LOG_FILE="/tmp/webserver_full_setup_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee "$LOG_FILE") 2>&1

echo "=== Starting Web Server Full Setup $(date) ==="

# Install required packages
echo "=== Installing Dependencies ==="
sudo apt-get update && sudo apt-get install -y \
  apache2 \
  nodejs npm \
  wget || { echo "Package install failed"; exit 1; }

# Set working directory (assumes script is run from the bundle dir)
cd "$(dirname "$0")"

# Install Node.js dependencies
echo "=== Installing Node.js Dependencies ==="
if [ -f package.json ]; then
  npm install || { echo "npm install failed"; exit 1; }
else
  echo "No package.json found — skipping npm install"
fi

# Copy web files to Apache root
echo "=== Deploying Web Files to Apache ==="
sudo cp *.html *.php *.css *.js /var/www/html/ || echo "Some file types may be missing — continuing"

# Configure systemd service
echo "=== Configuring Web Server Listener Service ==="
if [ -f "services/my-service.service" ]; then
  sudo cp services/my-service.service /etc/systemd/system/my-service.service || { echo "Failed to copy service file"; exit 1; }
  sudo systemctl daemon-reload
  sudo systemctl enable my-service.service
  sudo systemctl start my-service.service || {
    echo "⚠ Service start failed - checking logs"
    journalctl -u my-service.service -n 50 --no-pager
    exit 1
  }
fi

echo "Service Status:"
sudo systemctl status my-service.service --no-pager || true

echo "=== Web Server Full Setup Complete ==="
echo "Log file available at: $LOG_FILE"
